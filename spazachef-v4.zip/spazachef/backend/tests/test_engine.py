import random
from app import engine
B = dict(ingredients="rice, tinned tomatoes, one onion, chicken", serves=4, notes="no oven", diet="")
def test_respects_oven():
    for _ in range(30):
        r = engine.generate(B, "zanele", {}); assert r["archetype"] != "bake" and r["steps"]
def test_vegetarian_drops_meat():
    r = engine.generate({**B, "diet": "vegetarian"}, "farah", {}); assert not any("chicken" in i["item"] for i in r["ingredients"])
def test_learning_shifts_choice():
    w = {}
    for _ in range(40): engine.learn(w, "jabu", "pan", rating=5, cooked=True); engine.learn(w, "jabu", "grill", rating=1)
    picks = [engine.generate(B, "jabu", w, random.Random(i))["archetype"] for i in range(40)]
    assert picks.count("pan") > 25

def test_title_never_names_removed_meat():
    r = engine.generate({"ingredients": "chicken, rice", "diet": "vegetarian", "serves": 2}, "zanele", {})
    assert "chicken" not in r["title"].lower() and r["title"]

def test_forwarded_for_uses_last_hop():
    from app.main import who
    class R:  # minimal stand-in for starlette Request
        headers = {"x-forwarded-for": "6.6.6.6, 10.0.0.1"}; client = None
    uid, tier = who(R(), None)
    assert uid == "ip:10.0.0.1" and tier == "free"
